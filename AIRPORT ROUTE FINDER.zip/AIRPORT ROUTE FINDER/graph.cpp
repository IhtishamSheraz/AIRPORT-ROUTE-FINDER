// Graph.cpp
#include "Graph.h"
#include <queue>
#include <limits>
#include <algorithm>
#include <iostream>

using namespace std;

void Graph::addEdge(const string& from, const string& to, float weight) {
    if (from.empty() || to.empty()) {
        cerr << "Warning: Attempted to add edge with empty node name\n";
        return;
    }
    adjList[from].push_back(make_pair(to, weight));
    adjList[to].push_back(make_pair(from, weight));
}

const map<string, vector<pair<string, float>>>& Graph::getAdjList() const {
    return adjList;
}

vector<pair<string, float>> Graph::findShortestPath(const string& start, const string& end) {
    if (adjList.find(start) == adjList.end() || adjList.find(end) == adjList.end()) {
        cerr << "Pathfinding error: Start or end node not found\n";
        return {};
    }

    map<string, float> distances;
    map<string, string> previous;
    map<string, bool> visited;

    auto compare = [](const pair<float, string>& a, const pair<float, string>& b) {
        return a.first > b.first;
        };

    priority_queue<pair<float, string>,
        vector<pair<float, string>>,
        decltype(compare)> pq(compare);

    for (const auto& node : adjList) {
        distances[node.first] = numeric_limits<float>::max();
    }
    distances[start] = 0.0f;
    pq.push({ 0.0f, start });

    while (!pq.empty()) {
        auto current = pq.top().second;
        pq.pop();

        if (current == end) break;
        if (visited[current]) continue;
        visited[current] = true;

        for (const auto& neighbor : adjList.at(current)) {
            float alt = distances[current] + neighbor.second;
            if (alt < distances[neighbor.first]) {
                distances[neighbor.first] = alt;
                previous[neighbor.first] = current;
                pq.push({ alt, neighbor.first });
            }
        }
    }

    vector<pair<string, float>> path;
    if (previous.find(end) == previous.end() && start != end) {
        return path;
    }

    string current = end;
    while (current != start) {
        path.emplace_back(current, distances[current]);
        current = previous.at(current);
    }
    path.emplace_back(start, 0.0f);
    reverse(path.begin(), path.end());

    return path;
}