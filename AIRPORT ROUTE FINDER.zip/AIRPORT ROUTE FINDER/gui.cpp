﻿// gui.cpp
#include "gui.h"
#include <iostream>
#include <cmath>
#include <string>

using namespace std;
using namespace sf;

// Platform-specific includes for current directory
#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif

string getCurrentWorkingDirectory() {
#ifdef _WIN32
    char buffer[MAX_PATH];
    GetCurrentDirectoryA(MAX_PATH, buffer);
    return string(buffer);
#else
    char buffer[FILENAME_MAX];
    if (getcwd(buffer, FILENAME_MAX) != nullptr) {
        return string(buffer);
    }
    return "";
#endif
}

void handleZoom(RenderWindow& window, Event& event, View& view, float& zoomLevel) {
    if (event.type == Event::MouseWheelScrolled) {
        if (event.mouseWheelScroll.wheel == Mouse::VerticalWheel) {
            // Get mouse position before zoom
            Vector2i mousePos = Mouse::getPosition(window);
            Vector2f worldPosBefore = window.mapPixelToCoords(mousePos);

            // Apply zoom
            float zoomFactor = (event.mouseWheelScroll.delta > 0) ? 0.9f : 1.1f;
            zoomLevel *= zoomFactor;
            view.zoom(zoomFactor);
            window.setView(view);

            // Get mouse position after zoom
            Vector2f worldPosAfter = window.mapPixelToCoords(mousePos);

            // Adjust view to zoom toward mouse
            view.move(worldPosBefore - worldPosAfter);
            window.setView(view);
        }
    }
}

void handlePan(RenderWindow& window, Event& event, View& view,
    bool& isDragging, Vector2f& lastMousePos) {
    if (event.type == Event::MouseButtonPressed && event.mouseButton.button == Mouse::Left) {
        isDragging = true;
        lastMousePos = window.mapPixelToCoords(Vector2i(event.mouseButton.x, event.mouseButton.y));
    }
    else if (event.type == Event::MouseButtonReleased && event.mouseButton.button == Mouse::Left) {
        isDragging = false;
    }
    else if (event.type == Event::MouseMoved && isDragging) {
        Vector2f newPos = window.mapPixelToCoords(Vector2i(event.mouseMove.x, event.mouseMove.y));
        Vector2f delta = lastMousePos - newPos;
        view.move(delta);
        window.setView(view);
        lastMousePos = window.mapPixelToCoords(Vector2i(event.mouseMove.x, event.mouseMove.y));
    }
}

void drawGraph(const map<string, Vector2f>& locations,
    const vector<tuple<string, string, float, Color>>& paths,
    const vector<pair<string, float>>& fullPath) {

    if (locations.empty()) {
        cerr << "Error: No location data provided\n";
        return;
    }
    if (fullPath.empty()) {
        cerr << "Error: Empty flight path\n";
        return;
    }

    RenderWindow window(VideoMode(1200, 800), "Flight Route Animation (Scroll to zoom, Left-click drag to pan)");
    window.setFramerateLimit(60);

    // Load world map texture
    Texture worldMapTexture;
    if (!worldMapTexture.loadFromFile("world_map.png")) {
        cerr << "Error: Could not load world_map.png\n";
        cerr << "Current working directory: " << getCurrentWorkingDirectory() << "\n";
        return;
    }
    Sprite worldMap(worldMapTexture);
    worldMap.setScale(
        static_cast<float>(window.getSize().x) / worldMapTexture.getSize().x,
        static_cast<float>(window.getSize().y) / worldMapTexture.getSize().y
    );

    // Set up view for zooming/panning
    View view = window.getDefaultView();
    float zoomLevel = 1.0f;
    bool isDragging = false;
    Vector2f lastMousePos;

    Font font;
    if (!font.loadFromFile("arial.ttf")) {
        cerr << "Warning: Could not load font, using default\n";
    }

    // Create plane shape
    ConvexShape plane;
    plane.setPointCount(3);
    plane.setPoint(0, Vector2f(0, 0));
    plane.setPoint(1, Vector2f(20, 10));
    plane.setPoint(2, Vector2f(0, 20));
    plane.setFillColor(Color::Red);
    plane.setOrigin(10, 10);

    // Build animation path
    vector<Vector2f> pathPoints;
    for (size_t i = 1; i < fullPath.size(); i++) {
        const auto& from = fullPath[i - 1].first;
        const auto& to = fullPath[i].first;

        if (locations.find(from) == locations.end() || locations.find(to) == locations.end()) {
            continue;
        }

        const auto& start = locations.at(from);
        const auto& end = locations.at(to);
        const float segmentDist = fullPath[i].second - fullPath[i - 1].second;
        const int segments = max(1, static_cast<int>(segmentDist / 50.0f));

        for (int j = 0; j <= segments; j++) {
            float ratio = static_cast<float>(j) / segments;
            pathPoints.push_back(start + (end - start) * ratio);
        }
    }

    // Animation state
    size_t currentPoint = 0;
    float progress = 0.0f;
    Clock clock;

    while (window.isOpen()) {
        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed) {
                window.close();
            }
            handleZoom(window, event, view, zoomLevel);
            handlePan(window, event, view, isDragging, lastMousePos);
        }

        // Update animation
        if (!pathPoints.empty() && currentPoint + 1 < pathPoints.size()) {
            progress += clock.restart().asSeconds() * 2.0f;
            if (progress >= 1.0f) {
                progress = 0.0f;
                currentPoint = min(currentPoint + 1, pathPoints.size() - 2);
            }

            const auto& currentPos = pathPoints[currentPoint];
            const auto& nextPos = pathPoints[currentPoint + 1];
            const auto planePos = currentPos + (nextPos - currentPos) * progress;

            plane.setPosition(planePos);
            plane.setRotation(atan2(nextPos.y - currentPos.y, nextPos.x - currentPos.x) * 180.0f / 3.14159265f);
        }

        window.clear(Color::White);
        window.setView(view);

        // Draw world map background
        window.draw(worldMap);

        // Draw all connections
        for (const auto& path : paths) {
            const auto& from = get<0>(path);
            const auto& to = get<1>(path);

            if (locations.find(from) != locations.end() && locations.find(to) != locations.end()) {
                Vertex line[] = {
                    Vertex(locations.at(from), Color(200, 200, 200, 150)),
                    Vertex(locations.at(to), Color(200, 200, 200, 150))
                };
                window.draw(line, 2, Lines);
            }
        }

        // Draw active path
        for (size_t i = 1; i < fullPath.size(); i++) {
            const auto& from = fullPath[i - 1].first;
            const auto& to = fullPath[i].first;

            if (locations.find(from) != locations.end() && locations.find(to) != locations.end()) {
                const float dist = fullPath[i].second - fullPath[i - 1].second;
                Vertex line[] = {
                    Vertex(locations.at(from), Color(0, 120, 255, 200)),
                    Vertex(locations.at(to), Color(0, 120, 255, 200))
                };
                window.draw(line, 3, Lines);

                if (font.getInfo().family != "" && dist > 100.0f) {
                    Text distText(to_string(static_cast<int>(dist)) + " km", font, 12);
                    distText.setFillColor(Color(0, 120, 255));
                    distText.setPosition((locations.at(from) + locations.at(to)) * 0.5f);
                    window.draw(distText);
                }
            }
        }

        // Draw country markers
        for (const auto& loc : locations) {
            CircleShape marker(5);
            marker.setFillColor(Color::Red);
            marker.setOutlineThickness(1);
            marker.setOutlineColor(Color::White);
            marker.setOrigin(5, 5);
            marker.setPosition(loc.second);
            window.draw(marker);

            if (font.getInfo().family != "") {
                Text nameText(loc.first, font, 14);
                nameText.setFillColor(Color::White);
                nameText.setOutlineColor(Color::Black);
                nameText.setOutlineThickness(1);
                const auto bounds = nameText.getLocalBounds();
                nameText.setOrigin(bounds.width / 2, bounds.height);
                nameText.setPosition(loc.second.x, loc.second.y - 10);
                window.draw(nameText);
            }
        }

        if (!pathPoints.empty()) {
            window.draw(plane);
        }

        window.display();
    }
}