// gui.h
#ifndef GUI_H
#define GUI_H

#include <SFML/Graphics.hpp>
#include <vector>
#include <string>
#include <map>

using namespace std;
using namespace sf;

void drawGraph(const map<string, Vector2f>& locations,
    const vector<tuple<string, string, float, Color>>& paths,
    const vector<pair<string, float>>& fullPath);

void handleZoom(RenderWindow& window, Event& event, View& view, float& zoomLevel);
void handlePan(RenderWindow& window, Event& event, View& view,
    bool& isDragging, Vector2f& lastMousePos);

#endif