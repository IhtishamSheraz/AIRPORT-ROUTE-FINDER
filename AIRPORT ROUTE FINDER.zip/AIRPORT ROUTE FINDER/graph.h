// Graph.h
#ifndef GRAPH_H
#define GRAPH_H

#include <map>
#include <vector>
#include <string>
#include <utility>

using namespace std;

class Graph {
public:
    void addEdge(const string& from, const string& to, float weight);
    vector<pair<string, float>> findShortestPath(const string& start, const string& end);
    const map<string, vector<pair<string, float>>>& getAdjList() const;

private:
    map<string, vector<pair<string, float>>> adjList;
};

#endif // GRAPH_H