// main.cpp
#include <iostream>
#include <algorithm>
#include <cctype>
#include "Graph.h"
#include "gui.h"

using namespace std;
using namespace sf;

string trim(const string& str) {
    auto first = str.find_first_not_of(" \t\n\r");
    if (first == string::npos) return "";
    auto last = str.find_last_not_of(" \t\n\r");
    return str.substr(first, (last - first + 1));
}

int main() {
    Graph g;
    map<string, Vector2f> positions;

    // World map positions
    positions["Canada"] = Vector2f(150, 200);
    positions["USA"] = Vector2f(225, 320);
    positions["Mexico"] = Vector2f(225, 395);
    positions["UK"] = Vector2f(550, 250);
    positions["France"] = Vector2f(570, 290);
    positions["Germany"] = Vector2f(590, 270);
    positions["Russia"] = Vector2f(950, 200);
    positions["China"] = Vector2f(900, 350);
    positions["Japan"] = Vector2f(1030, 350);
    positions["India"] = Vector2f(830, 400);
    positions["Australia"] = Vector2f(1030, 650);
    positions["Brazil"] = Vector2f(400, 550);

    // Pakistan cities positions
    positions["Islamabad"] = Vector2f(795, 370);
    positions["Karachi"] = Vector2f(790, 390);
    positions["Lahore"] = Vector2f(793, 380);
    positions["Peshawar"] = Vector2f(830, 360);
    positions["Quetta"] = Vector2f(800, 375);

    // International flight connections
    g.addEdge("Canada", "USA", 800.0f);
    g.addEdge("USA", "Mexico", 2100.0f);
    g.addEdge("USA", "UK", 5800.0f);
    g.addEdge("UK", "France", 340.0f);
    g.addEdge("France", "Germany", 500.0f);
    g.addEdge("Germany", "Russia", 1600.0f);
    g.addEdge("Russia", "China", 3600.0f);
    g.addEdge("China", "Japan", 2100.0f);
    g.addEdge("China", "India", 2400.0f);
    g.addEdge("UK", "Canada", 5200.0f);
    g.addEdge("Brazil", "USA", 7500.0f);

    // Pakistan international connections
    g.addEdge("Islamabad", "UK", 6200.0f);
    g.addEdge("Karachi", "China", 3800.0f);
    g.addEdge("Lahore", "India", 500.0f);

    // Pakistan domestic flight connections
    g.addEdge("Islamabad", "Karachi", 1150.0f);
    g.addEdge("Islamabad", "Lahore", 280.0f);
    g.addEdge("Islamabad", "Peshawar", 180.0f);
    g.addEdge("Karachi", "Lahore", 1200.0f);
    g.addEdge("Karachi", "Quetta", 700.0f);
    g.addEdge("Lahore", "Peshawar", 400.0f);
    g.addEdge("Peshawar", "Quetta", 800.0f);

    cout << "Available countries/cities:\n";
    for (const auto& loc : positions) {
        cout << "- " << loc.first << "\n";
    }

    string start, end;
    cout << "\nEnter departure city/country: ";
    getline(cin, start);
    start = trim(start);

    cout << "Enter destination city/country: ";
    getline(cin, end);
    end = trim(end);

    if (positions.find(start) == positions.end() || positions.find(end) == positions.end()) {
        cerr << "\nError: Invalid city/country name(s) entered.\n";
        cerr << "Please enter exact names from the list (case-sensitive).\n";
        return 1;
    }

    auto path = g.findShortestPath(start, end);
    if (path.empty()) {
        cerr << "\nNo valid flight path between " << start << " and " << end << "\n";
        return 1;
    }

    cout << "\nOptimal Flight Route:\n";
    for (const auto& node : path) {
        cout << node.first << " (" << node.second << " km)\n";
    }

    vector<tuple<string, string, float, Color>> allConnections;
    for (const auto& node : g.getAdjList()) {
        const string& from = node.first;
        for (const auto& neighbor : node.second) {
            if (from < neighbor.first) {  // Avoid duplicate edges
                allConnections.emplace_back(from, neighbor.first, neighbor.second, Color::Blue);
            }
        }
    }

    drawGraph(positions, allConnections, path);

    return 0;
}